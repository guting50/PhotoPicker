package com.gt.photopicker.intent;

import android.support.v4.content.FileProvider;

public class PhotoPickerFileProvider extends FileProvider {
}
